const all = require('./all')

module.exports = {
  all
}
