export const getLiquidityChartData = () => [
  {
    date: '2021-12-03T09:23:53Z',
    amount: '50.35'
  },
  {
    date: '2021-12-12T09:23:53Z',
    amount: '104.78'
  },
  {
    date: '2021-12-21T09:23:53Z',
    amount: '130.45'
  },
  {
    date: '2021-12-30T09:23:53Z',
    amount: '203.98'
  },
  {
    date: '2022-01-01T09:23:53Z',
    amount: '150.35'
  },
  {
    date: '2022-01-08T09:23:53Z',
    amount: '260.45'
  },
  {
    date: '2022-01-11T09:23:53Z',
    amount: '330.98'
  },
]