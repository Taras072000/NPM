export const getAvailableClaim = () => [
  {
    address: "0xeC73559994D5E4Ca5a16a90a14203A2dae50b545",
    claimBefore: "12/12/2021 12:00:00 UTC",
    amount: "189,595.93",
    unit: "cxDAI",
  },
  {
    address: "0xeC73559994D5E4Ca5a16a90a14203A2dae50b545",
    claimBefore: "12/12/2021 12:00:00 UTC",
    amount: "189,595.93",
    unit: "cxDAI",
  },
  {
    address: "0xeC73559994D5E4Ca5a16a90a14203A2dae50b545",
    claimBefore: "12/12/2021 12:00:00 UTC",
    amount: "189,595.93",
    unit: "cxDAI",
  },
  {
    address: "0xeC73559994D5E4Ca5a16a90a14203A2dae50b545",
    claimBefore: "12/12/2021 12:00:00 UTC",
    amount: "189,595.93",
    unit: "cxDAI",
  },
]