export const StakingCardSubTitle = ({ text }) => (
  <div className="text-sm text-7398C0 uppercase mt-2">{text}</div>
);
