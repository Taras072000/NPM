export const StakingCardTitle = ({ text }) => (
  <h4 className="text-h4 font-sora font-semibold  mt-4">
    <span className="uppercase">{text}</span>
  </h4>
);
