export const TOAST_DEFAULT_TIMEOUT = 30000; //30 seconds
export const SHORT_TOAST_TIME = 5000; //5 seconds
export const ERROR_TOAST_TIME = 10000; //10 seconds

export const DEFAULT_VARIANT = "top_right";
