export const HeroTitle = ({ children }) => {
  return <h1 className="text-h2 font-sora font-bold">{children}</h1>;
};
