export const Hero = ({ children }) => {
  return <div className="bg-gradient-bg bg-cover bg-left">{children}</div>;
};
