describe("{{name}}", () => {
  it("should work", async () => {
    expect(typeof "hello").toBe("string");
  });
});
